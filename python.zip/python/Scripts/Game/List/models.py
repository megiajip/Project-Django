from django.db import models

class Games(models.Model):
    title = models.CharField(max_length=250)
    release = models.CharField(max_length=500)
    cpu = models.CharField(max_length=100)
    ram = models.CharField(max_length=100)
    os = models.CharField(max_length=100)
    disk = models.CharField(max_length=100)

    def __str__(self):
        return self.title + self.release + self.cpu+self.ram+self.os+self.disk
