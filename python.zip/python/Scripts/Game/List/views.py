from django.shortcuts import render
from .models import Games
from django.http import Http404
from django.template.response import TemplateResponse


def index(request):
    return render(request, 'games/index.html')

def home (request):
    return render (request,'games/home.html')

def about (request):
    return render (request,'games/about.html')

def dota2 (request):
    return render (request,'games/dota2.html')

def csgo (request):
    return render (request,'games/csgo.html')


def show(request):
    data = Games.objects.all()
    return TemplateResponse(request,'games/show.html',{"data":data})
    
